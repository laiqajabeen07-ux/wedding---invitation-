AYESHA & AWAIS WEDDING INVITATION  (Jabeen Customs Digital)
Upload the whole folder. Open index.html.

index.html                  everything: HTML + CSS + JavaScript (edit wedding details in PART 1 · CONFIG at the top of the <script>)
assets/jabeen-customs-logo.png
assets/couple-illustration.png       hero couple (faceless)
assets/couple-illustration-alt.png   closing couple (faceless)
assets/wedding-nasheed.mp3           background nasheed (you must hold the rights to publish it)

Before publishing:
- Mehndi map links: fill mapUrl in the events list (button appears automatically).
- Calendar: add endTime to each event, or set calendar.defaultDurationMinutes. Buttons stay off until then.
- Urdu lines under the duas are plain-language translations: have a scholar confirm or replace them (CONFIG > duas).

UPDATE (7 Nov): index.html is now fully standalone - the illustrations, logo and nasheed are embedded inside it, so it works even if opened alone.
Calendar buttons use an ASSUMED 4-hour length per function (WEDDING_CONFIG.calendar.defaultDurationMinutes). Change it if needed.
Names font: Pinyon Script (change --f-names in the CSS to swap).

UPDATE (7 Nov, 2): flowers are now ONLY your supplied rose images, cut from their backgrounds (assets/flowers/rose-corner.webp, rose-white.webp). Frames and border strips removed; sections flow continuously. Scratch reveal now bursts confetti sprinkles.

UPDATE (7 Nov, 3): continuous envelope animation (invitation reveals while the flap opens, no pause); Bismillah now in Scheherazade New (Google Fonts, needs internet; falls back to Amiri); flowers used selectively (envelope, hero, one duas side accent, wishes, closing); borders/frames removed; separators between sections.

CLIENT PREVIEW: double-click index.html. It needs no server; the photos, logo, roses and music are built into it (assets/ is kept as a backup copy). Only the fonts (Google Fonts) need internet; offline, simpler system fonts show instead.

WHATSAPP LINK PREVIEW (needs a public URL such as Netlify):
1. Upload the whole folder to Netlify.
2. In index.html, the sharing tags already point to https://ayesha-awais-wedding-invitation.netlify.app/ (change them only if the domain changes). The image is assets/og-share.jpg (1200x630).
3. WhatsApp caches previews: if you shared the link before, add ?v=2 to the link or re-scrape it with the Facebook Sharing Debugger.
A local file sent on WhatsApp will NOT show this preview.

UPDATE (8 Nov): Jabeen Customs Instagram promo added at the very end of the page (links to https://www.instagram.com/jabeen_customs/). WhatsApp numbers unchanged (groom's number to be updated after client approval: WEDDING_CONFIG.whatsapp.groomNumber in index.html).

UPDATE (9 Nov): groom's name first/above ("Awais Imran"), bride's below; short name "Awais & Ayesha" everywhere (incl. sharing tags and og-share.jpg). Music button now visible on the envelope screen; a soft magical chime plays when the envelope opens, always quieter than the music (silent if muted).

--- Update (round 3) ---
- Music autoplay attempt on load; falls back to first tap/key/click. Visitor pause is respected.
- Paper-plane (arrow) band removed with its spacing.
- Blessings section spacing reduced.
- RSVP + Dua merged into one form (bride side -> bride number only, groom side -> groom number only).
- Lantern button now repeats on every press.

--- Update (round 4) ---
- Music again starts directly from the envelope tap (autoplay-on-load and first-interaction fallback removed).

--- Final update ---
- Added family introductions above the names in the hero (config: WEDDING_CONFIG.family).
- Groom WhatsApp number updated to +92 325 6866899 (wa.me/923256866899). Bride number unchanged.

--- Final update: family lines, groom number, invitation links ---
CHANGES
- Hero: "Son of Mr. & Mrs. Imran" above Awais Imran; "Daughter of Mr. & Mrs. Muhammad Abdul Latif" above Ayesha Latif (WEDDING_CONFIG.family). No labels.
- Groom WhatsApp: +92 325 6866899 (wa.me/923256866899). Bride number unchanged (+32 465 66 77 69).
- Invitation links: each link decides which functions a guest sees. Guests are never asked for side/category/events.

PRIVATE DASHBOARD
- Open  https://YOUR-SITE/host/   (not linked anywhere on the guest site; marked noindex).
- Enter the host password, choose the family and the functions, add an optional label (only you see it), press "Generate Invitation Link".
- Each link has Copy Link and Preview Invitation. One link can be shared with any number of guests.
- Bride's Family cannot include Groom's Mehndi; Groom's Family cannot include Bride's Mehndi.
- The list of links is stored in the browser you use (not on a server): copy your links somewhere safe.

SETUP FOR SIGNED (TAMPER-PROOF) LINKS - Netlify Functions
1. Netlify > Site configuration > Environment variables, add:
   HOST_PASSWORD = a strong password only the hosts know
   INVITE_SECRET = a long random string (e.g. 40+ random characters). Do not share it. Do not change it later or old links stop working.
2. The functions live in netlify/functions/ (get-invite.js, create-invite.js) and netlify.toml points to them.
   Deploy with Git or the Netlify CLI (netlify deploy --prod) so the functions are built. Drag-and-drop deploys may not include functions: after deploying, check Netlify > Functions shows both functions.
3. Open /host/, unlock with the password. Links look like  https://YOUR-SITE/?i=b5-3859603a7eaa  and cannot be edited by guests.
If the functions are not set up, /host/ offers "basic links" (?side=bride&events=barat). They work but guests can edit the address; the site still blocks the opposite family's Mehndi.

STRICT MODE
- config  invitation: { strictLinks: false }  -> the plain website address still shows all functions (as before).
- Set strictLinks: true once signed links work: the plain address then shows no events, and only valid links reveal any.

HONEST LIMITS
- A link is not guest verification: anyone who receives a link can forward it.
- RSVP is still sent by the guest through WhatsApp, so the hosts should check the "Invited to" lines in each message.
- Hidden functions are removed from the page itself (cards, venue, maps, calendar, RSVP, countdown) for that visitor.
- When a link has no Barat, the countdown, scratch date and closing date follow that guest's first function.
- Calendar uses an assumed 4-hour duration; Mehndi map links are still empty.
